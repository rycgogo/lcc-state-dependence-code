# State-dependent marine low-cloud-cover analysis

Python code used to generate Figures 1--6 for the accompanying JGR: Atmospheres manuscript on the state dependence of marine low-cloud-cover responses to cloud-controlling factors.

## Data access

The processed 2.5-degree monthly analysis dataset for January 2007--December
2021 is archived separately on Zenodo: **[insert dataset DOI/URL after
publication]**. Download the NetCDF file and place it at:

```text
data/LCC_CALIPSO_MODIS_ERA5_Tadv_2.5deg_monthly_2007-2021.nc
```

The five scripts in `code/figures/` then resolve this path automatically.

## Run the figure scripts

```bash
pip install -r requirements.txt
python code/figures/fig02_lcc_sic_frequency.py
```

Generated figures and CSVs are written to `outputs/`.

## Provenance scripts

Scripts in `code/provenance/` document the processing of CALIPSO, MODIS, and
ERA5 data. They are not required to reproduce the manuscript figures. See
`SOURCE_DATA.md` for the official upstream products, citations, and expected
optional raw-input directories.

## Release and license

This repository corresponds to release `v1.0.0`. Before publishing, replace
the copyright placeholders in `LICENSE-CODE-MIT.txt` with the year and the
copyright holder(s), then select the MIT License in GitHub. Create a GitHub
release tagged `v1.0.0`, and archive that release in Zenodo to obtain the
software DOI.
